<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateReddingoOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('reddingo_orders', function (Blueprint $table) {
            $table->id();
            $table->string('order_id')->nullable(true);
            $table->string('reddingo_order_id')->nullable(true);
            $table->string('formatted_address')->nullable(true);
            $table->string('shippingCountry')->nullable(true);
            $table->string('shippingCountryCode')->nullable(true);
            $table->string('status')->nullable(true);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('reddingo_orders');
    }
}
