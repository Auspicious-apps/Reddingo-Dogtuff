<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOrderMetasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('order_metas', function (Blueprint $table) {
            $table->id();
            $table->string('order_name')->nullable(true);
            $table->string('order_id')->nullable(true);
            $table->string('sku')->nullable(true);
            $table->string('contact_email')->nullable(true);
            $table->string('total_price')->nullable(true);
            $table->string('line_text_1')->nullable(true);
            $table->string('line_text_2')->nullable(true);
            $table->string('line_text_3')->nullable(true);
            $table->string('line_text_4')->nullable(true);
            $table->string('line_text_5')->nullable(true);
            $table->string('line_text_6')->nullable(true);
            $table->string('back_line_text_1')->nullable(true);
            $table->string('back_line_text_2')->nullable(true);
            $table->string('back_line_text_3')->nullable(true);
            $table->string('back_line_text_4')->nullable(true);
            $table->string('back_line_text_5')->nullable(true);
            $table->string('back_line_text_6')->nullable(true);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('order_metas');
    }
}
