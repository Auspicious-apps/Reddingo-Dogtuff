@extends('shopify-app::layouts.default')

@section('content')
    <link rel="stylesheet" type="text/css" href="{{ url('/css/style.css') }}" />
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.3/css/bootstrap.min.css" />
    <link  href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
    <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">

    <div class="container">
        <div id="exTab1">            

            <ul class="nav tabs">
                <li class="active">
                    <a href="#1a" data-toggle="tab" data-id ="1a" class="active">Orders</a>
                </li>
                <li>
                    <a href="#2a" data-toggle="tab" data-id ="2a">Reddingo Orders</a>
                </li>

                <li>
                    <a href="#3a" data-toggle="tab" data-id ="3a">Settings</a>
                </li>
                
            </ul>

            <div class="tab-content clearfix">
                <div class="tab-pane active" id="1a">
                   @include('orders')
                </div>

                <div class="tab-pane" id="2a">
                   @include('reddingo')
                </div>

                <div class="tab-pane setting-tab" id="3a">
                    @include('settings',['shipping_carrier'=>$shipping_carrier,'tracking_url'=>$tracking_url])
                </div>
               
             </div>
        </div>
    </div>

@endsection

@section('scripts')
    @parent
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <script>
        actions.TitleBar.create(app, { title: 'Welcome' });
    </script>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <script src="http://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.2/js/toastr.min.js"></script>
    

<script>

    $(document).ready(function () {
        
        get_orders_list();
        get_reddingo_orders_list();

        // $.ajax({
        //     url: 'amazon-orders',
        //     type: "GET",
        //     dataType: 'json',
        //     success: function (data) {
                
        //         var oTable = $('#orders-table').dataTable();
        //             oTable.fnDraw(false);
            
        //     }
        // });

        
        $('body').on('click', '#editOrder', function (event) {

            event.preventDefault();
            var id = $(this).attr('data-id');
            console.log(id)   
            
            $("#order_id").val(id);
            
            var url = 'order-edit/' + id;
            
            $.ajax({

                headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                url: url,
                type: "GET",
                dataType: 'json',
                success: function (data) {
                    
                    $('.order_line').show();
                    
                    var l1 = data.data.line_text_1;
                    var l2 = data.data.line_text_2;
                    var l3 = data.data.line_text_3;
                    var l4 = data.data.line_text_4;
                    var l5 = data.data.line_text_5;
                    var l6 = data.data.line_text_6;
                    var b1 = data.data.back_line_text_1;
                    var b2 = data.data.back_line_text_2;
                    var b3 = data.data.back_line_text_3;
                    var b4 = data.data.back_line_text_4;
                    var b5 = data.data.back_line_text_5;
                    var b6 = data.data.back_line_text_6;
                    
                    if(l1 != null)
                    {
                        $("#order_line_1").val(data.data.line_text_1);
                    }
                    else
                    {
                        $("#line_1").hide();
                    }
                    
                    if(l2 != null)
                    {
                        $("#order_line_2").val(data.data.line_text_2);
                    }
                    else
                    {
                        $("#line_2").hide();
                    }
                    
                    if(l3 != null)
                    {
                        $("#order_line_3").val(data.data.line_text_3);
                    }
                    else
                    {
                        $("#line_3").hide();
                    }
                    
                    if(l4 != null)
                    {
                        $("#order_line_4").val(data.data.line_text_4);
                    }
                    else
                    {
                        $("#line_4").hide();
                    }
                    
                    if(l5 != null)
                    {
                        $("#order_line_5").val(data.data.line_text_5);
                    }
                    else
                    {
                        $("#line_5").hide();
                    }
                    
                    if(l6 != null)
                    {
                        $("#order_line_6").val(data.data.line_text_6);
                    }
                    else
                    {
                        $("#line_6").hide();
                    }
                    if(b1 != null)
                    {
                        $("#order_back_line_1").val(data.data.back_line_text_1);
                    }
                    else
                    {
                        $("#back_line_1").hide();
                    }
                    
                    if(b2 != null)
                    {
                        $("#order_back_line_2").val(data.data.back_line_text_2);
                    }
                    else
                    {
                        $("#back_line_2").hide();
                    }
                    
                    if(b3 != null)
                    {
                        $("#order_back_line_3").val(data.data.back_line_text_3);
                    }
                    else
                    {
                        $("#back_line_3").hide();
                    }
                    
                    if(b4 != null)
                    {
                        $("#order_back_line_4").val(data.data.back_line_text_4);
                    }
                    else
                    {
                        $("#back_line_4").hide();
                    }
                    
                    if(b5 != null)
                    {
                        $("#order_back_line_5").val(data.data.back_line_text_5);
                    }
                    else
                    {
                        $("#back_line_5").hide();
                    }
                    
                    if(b6 != null)
                    {
                        $("#order_back_line_6").val(data.data.back_line_text_6);
                    }
                    else
                    {
                        $("#back_line_6").hide();
                    }

                    if(l1 == null && l2 == null && l3 == null && l4 == null && l5 == null && l6 == null && b1 == null && b2 == null && b3 == null && b4 == null && b5 == null && b6 == null)
                    {

                        $("#line_1").val('');
                        $("#line_2").val('');
                        $("#line_3").val('');
                        $("#line_4").val('');
                        $("#line_5").val('');
                        $("#line_6").val('');                     
                        
                        
                        
                        $("#line_1").show();
                        $("#line_2").show();
                        $("#line_3").show();
                        $("#line_4").show();
                        $("#line_5").show();
                        $("#line_6").show();

                        $("#back_line_1").val('');
                        $("#back_line_2").val('');
                        $("#back_line_3").val('');
                        $("#back_line_4").val('');
                        $("#back_line_5").val('');
                        $("#back_line_6").val('');

                        $("#back_line_1").show();
                        $("#back_line_2").show();
                        $("#back_line_3").show();
                        $("#back_line_4").show();
                        $("#back_line_5").show();
                        $("#back_line_6").show();
                    }
                    
                    $('#order-edit-modal').modal('show');
                    
                    // $("#order_line_1").val(data.data.line_text_1);
                    // $("#order_line_2").val(data.data.line_text_2);
                    // $("#order_line_3").val(data.data.line_text_3);
                    // $("#order_line_4").val(data.data.line_text_4);
                    // $("#order_line_5").val(data.data.line_text_5);
                    // $("#order_line_6").val(data.data.line_text_6);
                }
            });
            
        });
        
        $('body').on('click', '#edit-order', function (event) {

            event.preventDefault()
            
            var line_1 = $("#order_line_1").val();
            var line_2 = $("#order_line_2").val();
            var line_3 = $("#order_line_3").val();
            var line_4 = $("#order_line_4").val();
            var line_5 = $("#order_line_5").val();
            var line_6 = $("#order_line_6").val();
            var back_line_1 = $("#order_back_line_1").val();
            var back_line_2 = $("#order_back_line_2").val();
            var back_line_3 = $("#order_back_line_3").val();
            var back_line_4 = $("#order_back_line_4").val();
            var back_line_5 = $("#order_back_line_5").val();
            var back_line_6 = $("#order_back_line_6").val();
            
            var id = $("#order_id").val();
            
            var url = 'order-update/' + id;
         
            $.ajax({
                url: url,
                type: "GET",
                data: {
                    line_1: line_1,
                    line_2: line_2,
                    line_3: line_3,
                    line_4: line_4,
                    line_5: line_5,
                    line_6: line_6,
                    back_line_1: back_line_1,
                    back_line_2: back_line_2,
                    back_line_3: back_line_3,
                    back_line_4: back_line_4,
                    back_line_5: back_line_5,
                    back_line_6: back_line_6,
                },

                dataType: 'json',
                success: function (data) {
                            
                    $('#order-edit-modal').modal('hide');
                    $('#order_edit_form').trigger("reset");
                    var oTable = $('#orders-table').dataTable();
                    oTable.fnDraw(false);
                }
            });
          
        });
        
        
        // $('body').on('click', '#sendOrder', function (event) {

        //     event.preventDefault();
        //     var id = $(this).attr('data-id');
        //     console.log(id)
            
        //     var url = 'create-tag/' + id;
            
        //     $.ajax({

        //         url: url,
        //         type: "POST",
        //         dataType: 'json',
        //         success: function (data) {
                    
        //             alert(data.data);
                   
        //         }
        //     });
            
        // });
        

        // $('body').on('click', '#sendOrder', function (event) {

        //     event.preventDefault();
        //     var id = $(this).attr('data-id');
        //     console.log(id)
            
        //     var url = 'red-tag';
            
        //     $.ajax({

        //         url: url,
        //         type: "GET",
        //         dataType: 'json',
        //         success: function (data) {
                    
        //             alert(data.data);
                   
        //         }
        //     });
            
        // });
        
        
        
        
        
        
        
        
        // $('body').on('click', '#all_orders', function (event) {
        
        //         $('input:checkbox[name="order_list"]').prop('checked', $(this).prop('checked'));

        // });
        
        // $('body').on('click', 'input:checkbox[name="order_list"]', function (event) {
        
        //   if ($('input:checkbox[name="order_list"]').length == $('input:checkbox[name="order_list"]:checked').length) {
        //         $("#all_orders").prop("checked", true);
        //     } else {
        //         $("#all_orders").prop('checked',false);
        //     }

        // });
        
        $('body').on('click', '#status-btn', function (event) {

                    
            $.ajax({
                url: 'reddingo-order-update',
                type: "GET",
                dataType: 'json',
                success: function (data) {

                         
                    var oTable = $('#reddingo-orders-table').dataTable();
                    oTable.fnDraw(false);
                            
                }
            });

        });


        $('body').on('click', '#settings-btn', function (event) {
                    
            var carrier = $('#shipping-carrier').val();
            var url = $('#tracking-url').val();
            
            
            $.ajax({
                url: 'save-settings',
                type: "POST",
                data: {shipping_carrier:carrier,tracking_url:url},
                dataType: 'json',
                success: function (data) {    
                    
                    toastr.info(' Values updated successfully!'); 
                            
                }
            });
        });

    });
    
    
    function get_orders_list()
    {

        $('#orders-table').DataTable({
            
            processing: true,
            serverSide: true,
            
            ajax: {
            url: "{{ url('order-list') }}",
            type: 'GET',
            },
            columns: [
            {data: 'id', name: 'id', 'visible': false},
            {data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false,searchable: false},
            { data: 'order_name', name: 'order_name' },
            { data: 'order_id', name: 'order_id', 'visible': false },
            { data: 'contact_email', name: 'contact_email' },
            { data: 'total_price', name: 'total_price' },
            { data: 'line_text_1', name: 'line_text_1' },
            { data: 'line_text_2', name: 'line_text_2' },
            { data: 'line_text_3', name: 'line_text_3' },
            { data: 'line_text_4', name: 'line_text_4' },
            { data: 'line_text_5', name: 'line_text_5' },
            { data: 'line_text_6', name: 'line_text_6' },
            { data: 'back_line_text_1', name: 'back_line_text_1' },
            { data: 'back_line_text_2', name: 'back_line_text_2' },
            { data: 'back_line_text_3', name: 'back_line_text_3' },
            { data: 'back_line_text_4', name: 'back_line_text_4' },
            { data: 'back_line_text_5', name: 'back_line_text_5' },
            { data: 'back_line_text_6', name: 'back_line_text_6' },
            {data: 'action', name: 'action', orderable: false},
            ],
            order: [[0, 'asc']]
            
        });
    }


    function get_reddingo_orders_list()
    {

        $('#reddingo-orders-table').DataTable({
            
            processing: true,
            serverSide: true,
            
            ajax: {
            url: "{{ url('reddingo-order-list') }}",
            type: 'GET',
            },
            columns: [
            {data: 'id', name: 'id', 'visible': false},
            {data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false,searchable: false},
            { data: 'order_id', name: 'order_id' },
            { data: 'reddingo_order_id', name: 'reddingo_order_id' },
            { data: 'formatted_address', name: 'formatted_address' },
            { data: 'shippingCountry', name: 'shippingCountry' },
            { data: 'shippingCountryCode', name: 'shippingCountryCode' },
            { data: 'status', name: 'status' },           
            ],
            order: [[0, 'asc']]
            
        });
    }
    
</script>  

@endsection