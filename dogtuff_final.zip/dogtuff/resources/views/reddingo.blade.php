<div class="reddingo-main">   
    
    <table class="table table-bordered table-striped" id="reddingo-orders-table">
        <thead>
            <tr>
                <th>Id</th>
                <th>S.No</th>
                <th>Order ID</th>
                <th>Reddingo Order ID</th>
                <th>Address</th>
                <th>Shipping Country</th>
                <th>Country Code</th>
                <th>Status</th>                
            </tr>
        </thead>
        <tbody>
            
        </tbody>       
    </table>
</div>