<div class="settings-main">

    <div class="content-section">

        <div class="message-one message">

            <div class="left">Shipping carrier</div>

            <div class="right">

                <input type="text" name="shipping-carrier" id="shipping-carrier" placeholder="Enter Carrier" value="{{ $shipping_carrier }}">               

            </div>
        </div>


        <div class="message-one message">

            <div class="left">Tracking URL</div>

            <div class="right">

                <input type="text" name="tracking-url" id="tracking-url" placeholder="Enter URL" value="{{ $tracking_url }}">
                
            </div>
        </div>

        <div id="settings-btn">Update</div>

    </div>

</div>