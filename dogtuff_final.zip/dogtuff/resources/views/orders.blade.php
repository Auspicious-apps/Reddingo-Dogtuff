<div class="order-main">
    
    
    <table class="table table-bordered table-striped" id="orders-table">
        <thead>
            <tr>
                <th>Id</th>
                <th>S.No</th>
                <th>Order ID</th>
                <th>Order ID</th>
                <th>Contact Email</th>
                <th>Total Price</th>
                <th>Line 1</th>
                <th>Line 2</th>
                <th>Line 3</th>
                <th>Line 4</th>
                <th>Line 5</th>
                <th>Line 6</th>
                <th>Back Line 1</th>
                <th>BackLine 2</th>
                <th>BackLine 3</th>
                <th>BackLine 4</th>
                <th>BackLine 5</th>
                <th>BackLine 6</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            
        </tbody>
       
    </table>
    
    <div class="modal" id="order-edit-modal" class="order-edit-modal" tabindex="-1" role="dialog">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title">Engraving Lines</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <form id="order_edit_form">

                      @csrf

                      <input type="hidden" id="order_id" name="order_id" value="">


                      <div class="form-group">
                        <div class="row">
                          <div class="col-sm-6 order_line" id="line_1">
                            <label for="name">  Line 1:   </label>
							    <input type="text" name="line_text_1" class="form-control" id="order_line_1" value="">
                          </div>
                          
                          <div class="col-sm-6 order_line" id="line_2">
                                 <label for="name">  Line 2:   </label>
							    <input type="text" name="line_text_2" class="form-control" id="order_line_2" value="">
                          </div>

                        </div>
                        
                        
                        <div class="row">
                          <div class="col-sm-6 order_line" id="line_3">
                            <label for="name">  Line 3:   </label>
							    <input type="text" name="line_text_3" class="form-control" id="order_line_3" value="">
                          </div>
                          
                          <div class="col-sm-6 order_line" id="line_4">
                                 <label for="name">  Line 4:   </label>
							    <input type="text" name="line_text_4" class="form-control" id="order_line_4" value="">
                          </div>

                        </div>
                        
                        <div class="row">
                          <div class="col-sm-6 order_line" id="line_5">
                            <label for="name">  Line 5:   </label>
							              <input type="text" name="line_text_5" class="form-control" id="order_line_5" value="">
                          </div>
                          
                          <div class="col-sm-6 order_line" id="line_6">
                            <label for="name">  Line 6:   </label>
							              <input type="text" name="line_text_6" class="form-control" id="order_line_6" value="">
                          </div>

                        </div>

                        <div class="row">
                          <div class="col-sm-6 order_line" id="back_line_1">
                            <label for="name"> Back Line 1:   </label>
							    <input type="text" name="back_line_text_1" class="form-control" id="order_back_line_1" value="">
                          </div>
                          
                          <div class="col-sm-6 order_line" id="back_line_2">
                                 <label for="name">  Back Line 2:   </label>
							    <input type="text" name="back_line_text_2" class="form-control" id="order_back_line_2" value="">
                          </div>

                        </div>
                        
                        
                        <div class="row">
                          <div class="col-sm-6 order_line" id="back_line_3">
                            <label for="name">  Back Line 3:   </label>
							    <input type="text" name="back_line_text_3" class="form-control" id="order_back_line_3" value="">
                          </div>
                          
                          <div class="col-sm-6 order_line" id="back_line_4">
                                 <label for="name"> Back Line 4:   </label>
							    <input type="text" name="back_line_text_4" class="form-control" id="order_back_line_4" value="">
                          </div>

                        </div>
                        
                        <div class="row">
                          <div class="col-sm-6 order_line" id="back_line_5">
                            <label for="name"> Back Line 5:   </label>
							    <input type="text" name="back_line_text_5" class="form-control" id="order_back_line_5" value="">
                          </div>
                          
                          <div class="col-sm-6 order_line" id="back_line_6">
                                 <label for="name"> Back Line 6:   </label>
							    <input type="text" name="back_line_text_6" class="form-control" id="order_back_line_6" value="">
                          </div>

                        </div>
                        
                      </div>

                        <span class="btn btn-primary" id="edit-order">Edit Order</span>

                    </form>
                  </div>
                </div>
              </div>
            </div>
    
    
    
</div>
