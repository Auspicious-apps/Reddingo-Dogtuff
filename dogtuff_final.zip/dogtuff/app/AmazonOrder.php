<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AmazonOrder extends Model
{
    //
}
