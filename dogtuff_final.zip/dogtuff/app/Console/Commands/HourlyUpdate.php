<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Order;
use App\OrderMeta;
use App\ReddingoOrder;

class HourlyUpdate extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'hour:update';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Check orders hourly';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        
        $get_details = Order::get(['id','order_id','billing_first_name','billing_last_name','billing_phone','billing_address1','contact_email','billing_city','billing_province_code','billing_zip','billing_address_country_code','line_text_1','line_text_2','line_text_3','line_text_4','line_text_5','line_text_6','back_line_text_1','back_line_text_2','back_line_text_3','back_line_text_4','back_line_text_5','back_line_text_6','total_quantity','sku','shipping_first_name','shipping_last_name','shipping_address_name','shipping_city','shipping_province_code','shipping_zip','shipping_country_code','doubleside_tag','created_at']);

        for($i=0;$i<count($get_details);$i++)
        {

            $order_create_time = $get_details[$i]->created_at;

            $time_diff = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $order_create_time)->diffInMinutes(\Carbon\Carbon::now());

            $time_diff = (float)$time_diff;

            if( $time_diff >= 4 )
            {

                $receiver = $get_details[$i]->shipping_first_name.' '.$get_details[$i]->shipping_last_name;
        
                $line_array = [];
                $back_line_array = [];
                $back_array_data = [];

                if($get_details[$i]->line_text_1 != null)
                {
                    $line_array[] = $get_details[$i]->line_text_1;
                }
                
                if($get_details[$i]->line_text_2 != null)
                {
                    $line_array[] = $get_details[$i]->line_text_2;
                }
                
                if($get_details[$i]->line_text_3 != null)
                {
                    $line_array[] = $get_details[$i]->line_text_3;
                }
                
                if($get_details[$i]->line_text_4 != null)
                {
                    $line_array[] = $get_details[$i]->line_text_4;
                }
                
                if($get_details[$i]->line_text_5 != null)
                {
                    $line_array[] = $get_details[$i]->line_text_5;
                }
                
                if($get_details[$i]->line_text_6 != null)
                {
                    $line_array[] = $get_details[$i]->line_text_6;
                }

                if($get_details[$i]->back_line_text_1 != null)
                {
                    $back_line_array[] = $get_details[$i]->back_line_text_1;
                }
                
                if($get_details[$i]->back_line_text_2 != null)
                {
                    $back_line_array[] = $get_details[$i]->back_line_text_2;
                }
                
                if($get_details[$i]->back_line_text_3 != null)
                {
                    $back_line_array[] = $get_details[$i]->back_line_text_3;
                }
                
                if($get_details[$i]->back_line_text_4 != null)
                {
                    $back_line_array[] = $get_details[$i]->back_line_text_4;
                }
                
                if($get_details[$i]->back_line_text_5 != null)
                {
                    $back_line_array[] = $get_details[$i]->back_line_text_5;
                }
                
                if($get_details[$i]->back_line_text_6 != null)
                {
                    $back_line_array[] = $get_details[$i]->back_line_text_6;
                }                

                $double_side = $get_details[$i]->doubleside_tag;

                if(sizeof($back_line_array) > 0)
                {
                    $double_sideed = true;
                    $back_array_data = $back_line_array;            
                }
                else
                {
                    $double_sideed = false;
                    $back_array_data = [];                
                }

                $url = "https://tags.reddingo.com/api/stores/submit/";

                    $curl = curl_init($url);
                    curl_setopt($curl, CURLOPT_URL, $url);
                    curl_setopt($curl, CURLOPT_POST, true);
                    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

                    $headers = array(
                    "Content-Type: application/json",
                    'Authorization: Basic '. base64_encode("hXtGEwDZyJFLYmXnEVaGRMZfpgQpAubhvpMjdVeCAWZvGGthgt:AJTVYhmnuMCfozBycPMkmaUcqmpvXFJmJk2JAoHEXTsAcGDAbQ")
                    );
                    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

                    $post_field_array =  array(
                        "AUDTORG"=>"REDUSA",
                        "IDCUST"=>"DOGTUFF",
                        "ownerFirstName" =>$get_details[$i]->billing_first_name,
                        "ownerLastName"=>$get_details[$i]->billing_last_name,
                        "petName"=>"", 
                        "ownerPhone"=>$get_details[$i]->billing_phone,
                        "ownerEmail"=>$get_details[$i]->contact_email,
                        "ownerAddress"=>$get_details[$i]->billing_addresses1,
                        "ownerSuburbTownCity"=>$get_details[$i]->billing_city,
                        "ownerStateProvinceRegion"=>$get_details[$i]->billing_province_code,
                        "ownerPostZipCode"=>$get_details[$i]->billing_zip,
                        "ownerCountryCode"=>$get_details[$i]->billing_address_country_code,
                        "receiver"=>$receiver,
                        "receiverAddress"=>$get_details[$i]->shipping_address_name,
                        "receiverSuburbTownCity"=>$get_details[$i]->shipping_city,   
                        "receiverStateProvinceRegion"=>$get_details[$i]->shipping_province_code,
                        "receiverPostZipCode"=>$get_details[$i]->shipping_zip,
                        "receiverCountryCode"=>$get_details[$i]->shipping_country_code,
                        "customerMessage"=>"",
                        "quantity"=>$get_details[$i]->total_quantity,
                        "tag"=>$get_details[$i]->sku,
                        "font"=>"engrave",
                        "doubleSided"=>$double_sideed,
                        "noEngraving"=>false,
                        "engravingLines"=> $line_array,  
                        "engravingLines2"=>$back_array_data, 
                        "sendToStore"=>false,
                        "reference"=>$get_details[$i]->order_id,
                        "emailStatusUpdates"=>false,
                        "draft"=>true,
                        
                    );

                    $reddingo_post_json_data = json_encode($post_field_array);  

                    curl_setopt($curl, CURLOPT_POSTFIELDS, $reddingo_post_json_data);

                    //for debug only!
                    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
                    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

                    $resp =  curl_exec($curl);

                    $status_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
                    
                    $response  = json_decode($resp);
                    
                    // $order = (array)$response;

                    if($status_code == 200)
                    {                    
                        $rorder = new ReddingoOrder;
                        $rorder->order_id = $get_details[$i]->order_id;
                        $rorder->reddingo_order_id = $response->order;
                        $rorder->formatted_address = $response->formattedAddress;
                        $rorder->shippingCountry = '';
                        $rorder->shippingCountryCode = '';
                        $rorder->status = $response->status;
                        $rorder->save();                   

                        Order::where('id',$get_details[$i]->id)->delete();
                        OrderMeta::where('order_id',$get_details[$i]->order_id)->where('sku',$get_details[$i]->sku)->delete();
                    }
            }            
                          
        }       
        
        return ('Hourly Update has been send successfully');
    }
}
