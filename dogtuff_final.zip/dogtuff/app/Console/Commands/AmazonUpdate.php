<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\AmazonOrder;
use App\Order;
use App\OrderMeta;

class AmazonUpdate extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'amazon:update';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Fetch amazon orders';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://0ea839db831916c25f4294ebc4f70b7c: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@dogtuff.myshopify.com/admin/api/2022-07/orders.json?status=open',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET' 
        ));
    
        $response = curl_exec($curl);

        curl_close($curl);
        
        $obj = json_decode($response);
                        
        $convert_array_obj = (array)$obj; 
        
        $orders = $convert_array_obj["orders"]; 

        $ids = [];
                                   
        for($i=0;$i<count($orders);$i++)
        {
            $order = $orders[$i];

            $line_items = [];

            $items = $order->line_items;

            $order_id = $order->id;

            $flag = 0;

            for($j=0;$j<count($items);$j++)
            {
                if(!empty($items[$j]->properties))
                {   
                    $flag = 1;
                    break;
                }
            }

            $order_exist = AmazonOrder::where('order_id',$order_id)->count();

            if($order->tags == 'amazon' && $flag == 1 && $order_exist == 0)
            {
                for($k=0;$k<count($items);$k++)
                {
                    
                    $line_data= [];
                    
                    $line_text_1 = null;
                    $line_text_2 = null;
                    $line_text_3 = null;
                    $line_text_4 = null;
                    $line_text_5 = null;
                    $line_text_6 = null;                   
                    
                    
                    $cancel_reason = $order->cancel_reason;
                    $confirmed = $order->confirmed;
                    $contact_email = $order->contact_email;
                    $current_subtotal_price = $order->current_subtotal_price;
                    $current_total_discounts = $order->current_total_discounts;
                    $current_total_price = $order->current_total_price;
                    $current_total_tax = $order->current_total_tax;
                    $name = $order->name;

                    $processing_method = $order->processing_method;

                    $fulfillable_quantity = $items[$k]->fulfillable_quantity;
                    $fulfillment_service =  $items[$k]->fulfillment_service;
                    $fulfillment_status =  $items[$k]->fulfillment_status;

                    // $original_location = $items[$k]->origin_location;


                    // $line_items_name  =  $original_location->name;
                    // $line_items_origin_location_address1 = $original_location->address1;
                    // $line_items_origin_location_city = $original_location->city;
                    // $line_items_origin_location_zip = $original_location->zip;

                    // billing address//

                    $billing_address = $order->billing_address;

                    $billing_first_name = $billing_address->first_name;
                    $billing_last_name = $billing_address->last_name;

                    $customer = $order->customer;
                    $default_address = $customer->default_address;

                    $billing_phone = $default_address->phone;
                    
                    $billing_address1 = $billing_address->address1;
                    
                    $checking_billing_address_1 =  $billing_address->address1;         
        
                    if(!empty($checking_billing_address_1)) {

                        $getchecking_billing_address_1 = $checking_billing_address_1.','.' ';

                    } else {

                            $getchecking_billing_address_1 ='';
                    }      
        
                    $billing_city = $billing_address->city;
                    $billing_province_code = $billing_address->province_code;
                    $billing_zip = $billing_address->zip;
                    $billing_address_province = $billing_address->province;
                    $billing_address_country_code = $billing_address->country_code;

                    
                    $billing_address_company = "";

                    if(!empty($billing_address_company)) {

                        $billing_company_address = $billing_address_company.','.' ';

                    } else {

                            $billing_company_address ='';
                    }

                    $billing_address2_company = "";
        
                    if(!empty($billing_address2_company)) {

                        $billing_address2 = $billing_address2_company;

                    } else {

                            $billing_address2 ='';
                    }

                    $billing_address = $billing_company_address.$getchecking_billing_address_1.$billing_address2;

                    $final_billing_addresses = trim($billing_address,", ");

                    // End  billing addres


                    $line_items_origin_product_id = $items[$k]->product_id;

                    $order_number = $order->order_number;
                
                    $customer_first_name = $customer->first_name;
                    $customer_last_name = $customer->last_name;

                    $customer_phone_number = $customer->phone;
                    
                    $financial_status = $order->financial_status;

                    $ship_lines = $order->shipping_lines;
                    
                    $delivery_method = $ship_lines[0]->code;

                    $double_tag = 0;

                    $line_variant = $items[$k]->variant_title;

                    $line_properties = $items[$k]->properties;

                    if (strpos($line_variant, 'Small') !== false) 
                    {
                        for($l=0; $l<count($line_properties); $l++)
                        {
                            if(isset($line_properties[$l]->value))
                            {
                                $property_name = $line_properties[$l]->name;

                                if($property_name == 'First Line S')
                                {
                                    $line_text = $line_properties[$l]->value;

                                    if(strpos($line_text, 'text :') !== false)
                                    {
                                        $last_word_start = strrpos($line_text, 'text :') + 7;
                                        $last_word = substr($line_text, $last_word_start);
                                        $line_text_1 = $last_word;
                                    }
                                }
                                else if($property_name == 'Second Line S')
                                {
                                    $line_text = $line_properties[$l]->value;

                                    if(strpos($line_text, 'text :') !== false)
                                    {
                                        $last_word_start = strrpos($line_text, 'text :') + 7;
                                        $last_word = substr($line_text, $last_word_start);
                                        $line_text_2 = $last_word;
                                    }
                                }
                                else if($property_name == 'Third Line S')
                                {
                                    $line_text = $line_properties[$l]->value;

                                    if(strpos($line_text, 'text :') !== false)
                                    {
                                        $last_word_start = strrpos($line_text, 'text :') + 7;
                                        $last_word = substr($line_text, $last_word_start);
                                        $line_text_3 = $last_word;
                                    }
                                }
                            }
                        }
                        
                        $line_data = [$line_text_1,$line_text_2,$line_text_3];
                    }
                    else if (strpos($line_variant, 'Medium') !== false) 
                    {
                        for($l=0; $l<count($line_properties); $l++)
                        {
                            if(isset($line_properties[$l]->value))
                            {
                                $property_name = $line_properties[$l]->name;

                                if($property_name == 'First Line M')
                                {
                                    $line_text = $line_properties[$l]->value;

                                    if(strpos($line_text, 'text :') !== false)
                                    {
                                        $last_word_start = strrpos($line_text, 'text :') + 7;
                                        $last_word = substr($line_text, $last_word_start);
                                        $line_text_1 = $last_word;
                                    }
                                }
                                else if($property_name == 'Second Line M')
                                {
                                    $line_text = $line_properties[$l]->value;

                                    if(strpos($line_text, 'text :') !== false)
                                    {
                                        $last_word_start = strrpos($line_text, 'text :') + 7;
                                        $last_word = substr($line_text, $last_word_start);
                                        $line_text_2 = $last_word;
                                    }
                                }
                                else if($property_name == 'Third Line M')
                                {
                                    $line_text = $line_properties[$l]->value;

                                    if(strpos($line_text, 'text :') !== false)
                                    {
                                        $last_word_start = strrpos($line_text, 'text :') + 7;
                                        $last_word = substr($line_text, $last_word_start);
                                        $line_text_3 = $last_word;
                                    }
                                }
                                else if($property_name == 'Fourth Line M')
                                {
                                    $line_text = $line_properties[$l]->value;

                                    if(strpos($line_text, 'text :') !== false)
                                    {
                                        $last_word_start = strrpos($line_text, 'text :') + 7;
                                        $last_word = substr($line_text, $last_word_start);
                                        $line_text_4 = $last_word;
                                    }
                                }
                                else if($property_name == 'Fifth Line M')
                                {
                                    $line_text = $line_properties[$l]->value;

                                    if(strpos($line_text, 'text :') !== false)
                                    {
                                        $last_word_start = strrpos($line_text, 'text :') + 7;
                                        $last_word = substr($line_text, $last_word_start);
                                        $line_text_5 = $last_word;
                                    }
                                }
                            }
                        }
                        
                        $line_data = [$line_text_1,$line_text_2,$line_text_3,$line_text_4,$line_text_5];
                    }
                    else if (strpos($line_variant, 'Large') !== false) 
                    {
                        for($l=0; $l<count($line_properties); $l++)
                        {
                            if(isset($line_properties[$l]->value))
                            {
                                $property_name = $line_properties[$l]->name;

                                if($property_name == 'First Line L')
                                {
                                    $line_text = $line_properties[$l]->value;

                                    if(strpos($line_text, 'text :') !== false)
                                    {
                                        $last_word_start = strrpos($line_text, 'text :') + 7;
                                        $last_word = substr($line_text, $last_word_start);
                                        $line_text_1 = $last_word;
                                    }
                                }
                                else if($property_name == 'Second Line L')
                                {
                                    $line_text = $line_properties[$l]->value;

                                    if(strpos($line_text, 'text :') !== false)
                                    {
                                        $last_word_start = strrpos($line_text, 'text :') + 7;
                                        $last_word = substr($line_text, $last_word_start);
                                        $line_text_2 = $last_word;
                                    }
                                }
                                else if($property_name == 'Third Line L')
                                {
                                    $line_text = $line_properties[$l]->value;

                                    if(strpos($line_text, 'text :') !== false)
                                    {
                                        $last_word_start = strrpos($line_text, 'text :') + 7;
                                        $last_word = substr($line_text, $last_word_start);
                                        $line_text_3 = $last_word;
                                    }
                                }
                                else if($property_name == 'Fourth Line L')
                                {
                                    $line_text = $line_properties[$l]->value;

                                    if(strpos($line_text, 'text :') !== false)
                                    {
                                        $last_word_start = strrpos($line_text, 'text :') + 7;
                                        $last_word = substr($line_text, $last_word_start);
                                        $line_text_4 = $last_word;
                                    }
                                }
                                else if($property_name == 'Fifth Line L')
                                {
                                    $line_text = $line_properties[$l]->value;

                                    if(strpos($line_text, 'text :') !== false)
                                    {
                                        $last_word_start = strrpos($line_text, 'text :') + 7;
                                        $last_word = substr($line_text, $last_word_start);
                                        $line_text_5 = $last_word;
                                    }
                                }
                                else if($property_name == 'Sixth Line L')
                                {
                                    $line_text = $line_properties[$l]->value;

                                    if(strpos($line_text, 'text :') !== false)
                                    {
                                        $last_word_start = strrpos($line_text, 'text :') + 7;
                                        $last_word = substr($line_text, $last_word_start);
                                        $line_text_6 = $last_word;
                                    }
                                }
                            }
                        }
                        
                        $line_data = [$line_text_1,$line_text_2,$line_text_3,$line_text_4,$line_text_5,$line_text_6];
                    }   
                    
                    
                    $total_quantity  = $items[$k]->quantity;
                    $sku  = $items[$k]->sku;

                    $shipping_address = $order->shipping_address;

                    $shipping_first_name = $shipping_address->first_name;
                    $shipping_last_name = $shipping_address->last_name;
                    $shipping_address_name = $shipping_address->address1;

                    if(!empty($shipping_address_name)) {

                        $get_shipping_address_name = $shipping_address_name.','.' ';

                    } else {

                        $get_shipping_address_name = '';
                    }          
        
        
                    $get_order_data_shiping_address2 = "";

                    if(!empty($get_order_data_shiping_address2)) {

                        $shipping_address2 = $get_order_data_shiping_address2;

                    } else {

                        $shipping_address2 = '';
                    }

                    $get_order_data_shiping_company_address2 ="comapny address";

                    if(!empty($get_order_data_shiping_company_address2)) {

                        $shipping_company = $get_order_data_shiping_company_address2.','.' ';

                    } else {

                        $shipping_company = '';
                    }

                    $get_shipping_addresses = $shipping_company.$get_shipping_address_name.$shipping_address2;

                    $final_shipping_Address  = trim($get_shipping_addresses,",");

                    $shipping_city = $shipping_address->city;
                    $shipping_country = $shipping_address->country;
                    $shipping_province_state = $shipping_address->province;
                    $shipping_province_code = $shipping_address->province_code;
                    $shipping_zip = $shipping_address->zip;
                    $shipping_country_code = $shipping_address->country_code;

                    $created_at = \Carbon\Carbon::now();

                    $values = array('order_id' => $order_id,'cancel_reason'=>$cancel_reason,'confirmed'=>$confirmed,'contact_email'=>$contact_email,'current_subtotal_price'=>$current_subtotal_price,'current_total_discounts'=>$current_total_discounts,'current_total_price'=>$current_total_price,'current_total_tax'=>$current_total_tax,'name'=>$name,'processing_method'=>$processing_method,'fulfillable_quantity'=>$fulfillable_quantity,'fulfillment_service'=>$fulfillment_service,'fulfillment_status'=>$fulfillment_status,'line_items_origin_location_address2'=>$shipping_address_name,'billing_first_name'=>$billing_first_name,'billing_last_name'=>$billing_last_name,'billing_phone'=>$billing_phone,'billing_address1'=>$billing_address1,'billing_city'=>$billing_city,'billing_province_code'=>$billing_province_code,'billing_zip'=>$billing_zip,'billing_address_province'=>$billing_address_province,'billing_address_country_code'=>$billing_address_country_code,'product_id'=>$line_items_origin_product_id,'order_number'=>$order_number,'customer_first_name'=>$customer_first_name,'customer_last_name'=>$customer_last_name,'customer_phone_number'=>$customer_phone_number,'financial_status'=>$financial_status,'delivery_method'=>$delivery_method,'line_text_1'=> $line_text_1,'line_text_2'=>$line_text_2,'line_text_3'=>$line_text_3,'line_text_4'=>$line_text_4,'line_text_5'=>$line_text_5,'line_text_6'=>$line_text_6,'total_quantity'=>$total_quantity,'sku'=>$sku,'shipping_first_name'=>$shipping_first_name,'shipping_last_name'=>$shipping_last_name,'shipping_address_name'=>$shipping_address_name,'shipping_city'=>$shipping_city,'shipping_country'=>$shipping_country,'shipping_province_state'=>$shipping_province_state,'shipping_province_code'=>$shipping_province_code,'shipping_zip'=>$shipping_zip,'shipping_country_code'=>$shipping_country_code,'doubleside_tag'=>$double_tag,'created_at'=>$created_at);

                    $meta_values = array('order_name'=>$name,'order_id' => $order_id,'sku' => $sku,'contact_email'=>$contact_email,'total_price'=>$current_total_price,'line_text_1'=> $line_text_1,'line_text_2'=> $line_text_2,'line_text_3'=> $line_text_3,'line_text_4'=> $line_text_4,'line_text_5'=> $line_text_5,'line_text_6'=> $line_text_6);
                    
                    if($line_text_1 != null)
                    {
                        AmazonOrder::insert($values);
                        Order::insert($values);
                        OrderMeta::insert($meta_values);
                    }      

                }                
            }        
        }        

    }
}
