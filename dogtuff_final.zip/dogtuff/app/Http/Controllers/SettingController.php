<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Setting;

class SettingController extends Controller
{
    

    public function save_settings(Request $request)
    {

        $shipping_carrier = $request->input('shipping_carrier');
        $tracking_url = $request->input('tracking_url');

        Setting::where('name','shipping_carrier')->update([

            'value' => $shipping_carrier

        ]);

        Setting::where('name','tracking_url')->update([

            'value' => $tracking_url

        ]);

        $view = view('settings',['shipping_carrier'=>$shipping_carrier,'tracking_url'=>$tracking_url ]);
        
        return response()->json(['success' => true]);       

    }


    

}
