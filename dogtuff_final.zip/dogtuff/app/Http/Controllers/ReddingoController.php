<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\ReddingoOrder;
use App\Setting;

class ReddingoController extends Controller
{
    
    public function get_reddingo_orders(Request $request)
    {
        
        $orders = ReddingoOrder::get(['*']);
        
        return datatables()->of($orders)
        ->addIndexColumn()
        ->make(true);        
    }


    Public function get_order_status(Request $request)
    {
        $REQUEST_BODY = file_get_contents('php://input');
        $values = json_decode($REQUEST_BODY, true);
        // $message = json_encode(json_decode($REQUEST_BODY, true), JSON_PRETTY_PRINT);
        // mail('scott@dogtuff.com', 'Tags Web Hook', $message);

        $order = $values['order'];
        $red_order_id = $order['order'];
        $status = $order['status'];
        $usps_tracking_url = $order['trackingURL'];

        $check_availability = ReddingoOrder::where('reddingo_order_id',$red_order_id)->count();

        if($check_availability > 0)
        {
            ReddingoOrder::where('reddingo_order_id',$red_order_id)->update(['status' => $status]);
        }

        
        if($status == 'DONE')
        {

            $raw_order_id = ReddingoOrder::where('reddingo_order_id',$red_order_id)->get(['order_id']);

            $order_id = $raw_order_id[0]->order_id;

            $carrier = Setting::where('name','shipping_carrier')->get(['value']);
            $url = Setting::where('name','tracking_url')->get(['value']);

            $cust_shipping_carrier = $carrier[0]->value;
            $cust_tracking_url = $url[0]->value;     
            
            if($usps_tracking_url != null)
            {
                $shipping_carrier = 'USPS';
                $tracking_url = $usps_tracking_url;
            }
            else
            {
                $shipping_carrier = $cust_shipping_carrier;
                $tracking_url =  $cust_tracking_url; 
            }            

            $headers = array(
                "Content-Type: application/json",
                "Accept: application/json",
            );

            // $curl = curl_init();
            // curl_setopt_array($curl, array(
            //     CURLOPT_URL => 'https://0ea839db831916c25f4294ebc4f70b7c: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@dogtuff-demo.myshopify.com/admin/api/2023-04/orders/'.$order_id.'.json?fields=note_attributes',
            //     CURLOPT_RETURNTRANSFER => true,
            //     CURLOPT_ENCODING => '',
            //     CURLOPT_MAXREDIRS => 10,
            //     CURLOPT_TIMEOUT => 0,
            //     CURLOPT_FOLLOWLOCATION => true,
            //     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            //     CURLOPT_CUSTOMREQUEST => 'GET',
            // ));
                
            // $response = curl_exec($curl);
            // curl_close($curl);
            
            // $obj = json_decode($response);
                        
            // $convert_array_obj = (array)$obj; 
        
            // $orders = $convert_array_obj["order"];

            // $note_attributes = $orders->note_attributes;

            // $attribute1 = ["name"=>"Shipping carrier","value"=>$shipping_carrier];
            // $attribute2 = ["name"=>"Tracking URL","value"=>$tracking_url];

            // $note_attributes[] = $attribute1;
            // $note_attributes[] = $attribute2;  

            // $formatted_note_attributes = json_encode($note_attributes);
            

            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => 'https://0ea839db831916c25f4294ebc4f70b7c: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@dogtuff-demo.myshopify.com/admin/api/2023-04/orders/'.$order_id.'.json',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'PUT',
                CURLOPT_POSTFIELDS =>'{"order":{"id":'.$order_id.',"note_attributes":[{"name":"Shipping carrier","value":"'.$shipping_carrier.'"},{"name":"Tracking URL","value":"'.$tracking_url.'"}]}}',
                // CURLOPT_POSTFIELDS =>'{"order":{"id":'.$order_id.',"note_attributes":'.$formatted_note_attributes.'}}',
                curl_setopt($curl, CURLOPT_HTTPHEADER, $headers)
            ));
                
            $response1 = curl_exec($curl);

            curl_close($curl); 

            return $response1;
        }           
    }
    
    

}
