<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\OrderMeta;
use App\Order;
use App\ReddingoOrder;

class OrderController extends Controller
{
    public function order_create(Request $requset)
    {

        $webhook_order  =  file_get_contents('php://input');
        $get_order_data  =  json_decode($webhook_order,true);

        for($i=0;$i<count($get_order_data["line_items"]);$i++)
        {
            
            $line_data = [];
            $back_line_data = [];

            $line_text_1 = null;
            $line_text_2 = null;
            $line_text_3 = null;
            $line_text_4 = null;
            $line_text_5 = null;
            $line_text_6 = null;

            $back_line_text_1 = null;
            $back_line_text_2 = null;
            $back_line_text_3 = null;
            $back_line_text_4 = null;
            $back_line_text_5 = null;
            $back_line_text_6 = null;

            // check properties

            if(!empty($get_order_data['line_items'][$i]['properties']))
            {
                if(!empty($get_order_data['line_items'][$i]['properties'][0]['value']))        
                {
                                       
                    if($get_order_data['line_items'][$i]['properties'][0]['value'] == 'pet_ids')
                    {        
                        
                        $order_id = $get_order_data['id'];
                    
                        $cancel_reason = $get_order_data['cancel_reason'];

                        $confirmed = $get_order_data['confirmed'];
                        $contact_email = $get_order_data['contact_email'];


                        $current_subtotal_price = $get_order_data['current_subtotal_price'];

                        $current_total_discounts = $get_order_data['current_total_discounts'];
                        $current_total_price = $get_order_data['current_total_price'];


                        $current_total_tax = $get_order_data['current_total_tax'];
                        $name = $get_order_data['name'];


                        $processing_method = $get_order_data['processing_method'];

                        $fulfillable_quantity = $get_order_data['line_items'][$i]['fulfillable_quantity'];
                        $fulfillment_service =  $get_order_data['line_items'][$i]['fulfillment_service'];
                        $fulfillment_status =  $get_order_data['line_items'][$i]['fulfillment_status'];
                        $line_items_name  =  $get_order_data['line_items'][$i]['origin_location']['name'];

                        $line_items_origin_location_address1 = $get_order_data['line_items'][$i]['origin_location']['address1'];
                        // $line_items_origin_location_address2 = $get_order_data['line_items'][0]['origin_location']['address2'];

                        $line_items_origin_location_city = $get_order_data['line_items'][$i]['origin_location']['city'];
                        $line_items_origin_location_zip = $get_order_data['line_items'][$i]['origin_location']['zip'];

                        // billing address//

                        $billing_first_name = $get_order_data['billing_address']['first_name'];
                        $billing_last_name = $get_order_data['billing_address']['last_name'];

                        $billing_phone = $get_order_data['customer']['default_address']['phone'];
                        
                        $billing_address1 = $get_order_data['billing_address']['address1'];
                        
                        $checking_billing_address_1 =  $get_order_data['billing_address']['address1'];         
            
                        if(!empty($checking_billing_address_1)) {

                            $getchecking_billing_address_1 = $checking_billing_address_1.','.' ';

                        } else {

                                $getchecking_billing_address_1 ='';
                        }
            
            
                        $billing_city = $get_order_data['billing_address']['city'];
                        $billing_province_code = $get_order_data['billing_address']['province_code'];
                        $billing_zip = $get_order_data['billing_address']['zip'];


                        $billing_address_province = $get_order_data['billing_address']['province'];
                        $billing_address_country_code = $get_order_data['billing_address']['country_code'];

                        
                        $billing_address_company = "";

                        if(!empty($billing_address_company)) {

                            $billing_company_address = $billing_address_company.','.' ';

                        } else {

                                $billing_company_address ='';
                        }

                        $billing_address2_company = "";
            
                        if(!empty($billing_address2_company)) {

                            $billing_address2 = $billing_address2_company;

                        } else {

                                $billing_address2 ='';
                        }

                        $billing_address = $billing_company_address.$getchecking_billing_address_1.$billing_address2;

                        $final_billing_addresses = trim($billing_address,", ");

                        // End  billing addres


                        $line_items_origin_product_id = $get_order_data['line_items'][$i]['product_id'];

                        //  $line_items_origin_country_code = $get_order_data['line_items'][0]['origin_location']['country_code'];

                        $order_number = $get_order_data['order_number'];
                    
                        $customer_first_name = $get_order_data['customer']['first_name'];
                        $customer_last_name = $get_order_data['customer']['last_name'];

                        $customer_phone_number = $get_order_data['customer']['phone'];
                        
                        $financial_status = $get_order_data['financial_status'];
                        
                        $delivery_method = $get_order_data['shipping_lines'][0]['code'];


                        /*
                        * Add engraving field in database
                        *
                        */ 

                            // $dog_name_properties  = $get_order_data['line_items'][0]['properties'][1]['value'];

                        /*
                        *
                        *
                        */

                        $line_variant = $get_order_data['line_items'][$i]['variant_title'];

                        $line_properties = $get_order_data['line_items'][$i]['properties'];

                        $double_tag = 0;

                        if (strpos($line_variant, 'Small') !== false) {

                            for($k=0; $k<count($line_properties); $k++)
                            {

                                if(isset($get_order_data['line_items'][$i]['properties'][$k]['value'])) {
                                    
                                    $property_name = $get_order_data['line_items'][$i]['properties'][$k]['name'];
                                    
                                    if($property_name == 'First Line - S')
                                    {
                                        
                                        $line_text = $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        
                                        if($line_text != '')
                                        {
                                            $line_text_1   =  $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        }                                            
                                        
                                    }
                                    else if($property_name == 'Second Line - S')
                                    {
                                        $line_text = $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                       
                                        if($line_text != '')
                                        {
                                            $line_text_2   =  $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        }
                                       
                                    }
                                    else if($property_name == 'Third Line - S')
                                    {
                                        $line_text = $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                      
                                        if($line_text != '')
                                        {
                                            $line_text_3   =  $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        }
                                        
                                    } 
                                    else if($property_name == 'Back First Line - S')
                                    {
                                        $line_text = $get_order_data['line_items'][$i]['properties'][$k]['value'];

                                        if($line_text != '')
                                        {
                                            $back_line_text_1   =  $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        }
                                        
                                    }
                                    else if($property_name == 'Back Second Line - S')
                                    {
                                        $line_text = $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        
                                        if($line_text != '')
                                        {
                                            $back_line_text_2   =  $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        }
                                        
                                    }
                                    else if($property_name == 'Back Third Line - S')
                                    {
                                        $line_text = $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        
                                        if($line_text != '')
                                        {
                                            $back_line_text_3   =  $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        }
                                        
                                    } 
                                    else if($property_name == '_tagType')
                                    {
                                        $double_tag = 1;
                                    }          
                                    
                                }                                                    
                            } 

                            $line_data = [$line_text_1,$line_text_2,$line_text_3];
                            $back_line_data = [$back_line_text_1,$back_line_text_2,$back_line_text_3];

                        }               
                        else if (strpos($line_variant, 'Medium') !== false) {

                            for($k=0; $k<count($line_properties); $k++)
                            {

                                if(isset($get_order_data['line_items'][$i]['properties'][$k]['value'])) {

                                    $property_name = $get_order_data['line_items'][$i]['properties'][$k]['name'];

                                    if($property_name == 'First Line - M')
                                    {
                                        $line_text = $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                       
                                        if($line_text != '')
                                        {
                                            $line_text_1   =  $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        }
                                       
                                    }
                                    else if($property_name == 'Second Line - M')
                                    {
                                        $line_text = $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                       
                                        if($line_text != '')
                                        {
                                            $line_text_2   =  $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        }
                                        
                                    }
                                    else if($property_name == 'Third Line - M')
                                    {
                                        $line_text = $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        
                                        if($line_text != '')
                                        {
                                            $line_text_3   =  $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        }
                                       
                                    }   
                                    else if($property_name == 'Fourth Line - M')
                                    {
                                        $line_text = $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        
                                        if($line_text != '')
                                        {
                                            $line_text_4   =  $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        }
                                        
                                    }   
                                    else if($property_name == 'Fifth Line - M')
                                    {
                                        $line_text = $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        
                                        if($line_text != '')
                                        {
                                            $line_text_5   =  $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        }
                                        
                                    } 
                                    else if($property_name == 'Back First Line - M')
                                    {
                                        $line_text = $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        
                                        if($line_text != '')
                                        {
                                            $back_line_text_1   =  $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        }
                                        
                                    }
                                    else if($property_name == 'Back Second Line - M')
                                    {
                                        $line_text = $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        
                                        if($line_text != '')
                                        {
                                            $back_line_text_2   =  $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        }
                                        
                                    }
                                    else if($property_name == 'Back Third Line - M')
                                    {
                                        $line_text = $get_order_data['line_items'][$i]['properties'][$k]['value'];

                                        if($line_text != '')
                                        {
                                            $back_line_text_3   =  $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        }
                                        
                                    }   
                                    else if($property_name == 'Back Fourth Line - M')
                                    {
                                        $line_text = $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        
                                        if($line_text != '')
                                        {
                                            $back_line_text_4   =  $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        }
                                        
                                    }   
                                    else if($property_name == 'Back Fifth Line - M')
                                    {
                                        $line_text = $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        
                                        if($line_text != '')
                                        {
                                            $back_line_text_5   =  $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        }
                                        
                                    }
                                    else if($property_name == '_tagType')
                                    {
                                        $double_tag = 1;
                                    }       
                                }                        
                            } 

                            $line_data = [$line_text_1,$line_text_2,$line_text_3,$line_text_4,$line_text_5];
                            $back_line_data = [$back_line_text_1,$back_line_text_2,$back_line_text_3,$back_line_text_4,$back_line_text_5];
                        }
                        else if (strpos($line_variant, 'Large') !== false) {

                            for($k=0; $k<count($line_properties); $k++)
                            {

                                if(isset($get_order_data['line_items'][$i]['properties'][$k]['value'])) {

                                    $property_name = $get_order_data['line_items'][$i]['properties'][$k]['name'];

                                    if($property_name == 'First Line - L')
                                    {
                                        $line_text = $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        
                                        if($line_text != '')
                                        {
                                            $line_text_1   =  $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        }
                                      
                                    }
                                    else if($property_name == 'Second Line - L')
                                    {
                                        $line_text = $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        
                                        if($line_text != '')
                                        {
                                            $line_text_2   =  $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        }
                                        
                                    }
                                    else if($property_name == 'Third Line - L')
                                    {
                                        $line_text = $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        
                                        if($line_text != '')
                                        {
                                            $line_text_3   =  $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        }
                                        
                                    }   
                                    else if($property_name == 'Fourth Line - L')
                                    {
                                        $line_text = $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        
                                        if($line_text != '')
                                        {
                                            $line_text_4   =  $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        }
                                        
                                    }   
                                    else if($property_name == 'Fifth Line - L')
                                    {
                                        $line_text = $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        
                                        if($line_text != '')
                                        {
                                            $line_text_5   =  $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        }
                                        
                                    }  
                                    else if($property_name == 'Sixth Line - L')
                                    {
                                        $line_text = $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        
                                        if($line_text != '')
                                        {
                                            $line_text_6   =  $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        }
                                        
                                    }
                                    else if($property_name == 'Back First Line - L')
                                    {
                                        $line_text = $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        
                                        if($line_text != '')
                                        {
                                            $back_line_text_1   =  $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        }
                                        
                                    }
                                    else if($property_name == 'Back Second Line - L')
                                    {
                                        $line_text = $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        
                                        if($line_text != '')
                                        {
                                            $back_line_text_2   =  $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        }
                                        
                                    }
                                    else if($property_name == 'Back Third Line - L')
                                    {
                                        $line_text = $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        
                                        if($line_text != '')
                                        {
                                            $back_line_text_3   =  $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        }
                                        
                                    }   
                                    else if($property_name == 'Back Fourth Line - L')
                                    {
                                        $line_text = $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        
                                        if($line_text != '')
                                        {
                                            $back_line_text_4   =  $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        }
                                        
                                    }   
                                    else if($property_name == 'Back Fifth Line - L')
                                    {
                                        $line_text = $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        
                                        if($line_text != '')
                                        {
                                            $back_line_text_5   =  $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        }
                                        
                                    }  
                                    else if($property_name == 'Back Sixth Line - L')
                                    {
                                        $line_text = $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        
                                        if($line_text != '')
                                        {
                                            $back_line_text_6   =  $get_order_data['line_items'][$i]['properties'][$k]['value'];
                                        }
                                        
                                    }
                                    else if($property_name == '_tagType')
                                    {
                                        $double_tag = 1;
                                    }        
                                }
                            }
                            
                            $line_data = [$line_text_1,$line_text_2,$line_text_3,$line_text_4,$line_text_5,$line_text_6];
                            $back_line_data = [$back_line_text_1,$back_line_text_2,$back_line_text_3,$back_line_text_4,$back_line_text_5,$back_line_text_6];
                        }

                        // end engraving line 

                        $total_quantity  = $get_order_data['line_items'][$i]['quantity'];

                        $sku  = $get_order_data['line_items'][$i]['sku'];

                        $shipping_first_name = $get_order_data['shipping_address']['first_name'];
                        $shipping_last_name = $get_order_data['shipping_address']['last_name'];
                        $shipping_address_name = $get_order_data['shipping_address']['address1'];
                        
                        
                        if(!empty($shipping_address_name)) {

                            $get_shipping_address_name = $shipping_address_name.','.' ';

                        } else {

                            $get_shipping_address_name = '';
                        }          
            
            
                        $get_order_data_shiping_address2 = "";

                        if(!empty($get_order_data_shiping_address2)) {

                            $shipping_address2 = $get_order_data_shiping_address2;

                        } else {

                            $shipping_address2 = '';
                        }

                    
                        $get_order_data_shiping_company_address2 ="comapny address";
                
                        if(!empty($get_order_data_shiping_company_address2)) {

                            $shipping_company = $get_order_data_shiping_company_address2.','.' ';

                        } else {

                            $shipping_company = '';
                        }

                        $get_shipping_addresses = $shipping_company.$get_shipping_address_name.$shipping_address2;

                        $final_shipping_Address  = trim($get_shipping_addresses,",");

                        //new add 

                        $shipping_city = $get_order_data['shipping_address']['city'];
                        $shipping_country = $get_order_data['shipping_address']['country'];
                        $shipping_province_state = $get_order_data['shipping_address']['province'];
                        $shipping_province_code = $get_order_data['shipping_address']['province_code'];
                        $shipping_zip = $get_order_data['shipping_address']['zip'];
                        $shipping_country_code = $get_order_data['shipping_address']['country_code'];

                        // End 
                    
                        /*
                        * end 
                        *
                        */

                        $created_at = \Carbon\Carbon::now();

                        $values = array('order_id' => $order_id,'cancel_reason'=>$cancel_reason,'confirmed'=>$confirmed,'contact_email'=>$contact_email,'current_subtotal_price'=>$current_subtotal_price,'current_total_discounts'=>$current_total_discounts,'current_total_price'=>$current_total_price,'current_total_tax'=>$current_total_tax,'name'=>$name,'processing_method'=>$processing_method,'fulfillable_quantity'=>$fulfillable_quantity,'fulfillment_service'=>$fulfillment_service,'fulfillment_status'=>$fulfillment_status,'line_items_name'=>$line_items_name,'line_items_origin_location_address1'=>$line_items_origin_location_address1,'line_items_origin_location_address2'=>$shipping_address_name,'line_items_origin_location_city'=>$line_items_origin_location_city,'line_items_origin_location_zip'=>$line_items_origin_location_zip,'billing_first_name'=>$billing_first_name,'billing_last_name'=>$billing_last_name,'billing_phone'=>$billing_phone,'billing_address1'=>$billing_address1,'billing_city'=>$billing_city,'billing_province_code'=>$billing_province_code,'billing_zip'=>$billing_zip,'billing_address_province'=>$billing_address_province,'billing_address_country_code'=>$billing_address_country_code,'product_id'=>$line_items_origin_product_id,'order_number'=>$order_number,'customer_first_name'=>$customer_first_name,'customer_last_name'=>$customer_last_name,'customer_phone_number'=>$customer_phone_number,'financial_status'=>$financial_status,'delivery_method'=>$delivery_method,'line_text_1'=> $line_text_1,'line_text_2'=>$line_text_2,'line_text_3'=>$line_text_3,'line_text_4'=>$line_text_4,'line_text_5'=>$line_text_5,'line_text_6'=>$line_text_6,'back_line_text_1'=> $back_line_text_1,'back_line_text_2'=>$back_line_text_2,'back_line_text_3'=>$back_line_text_3,'back_line_text_4'=>$back_line_text_4,'back_line_text_5'=>$back_line_text_5,'back_line_text_6'=>$back_line_text_6,'total_quantity'=>$total_quantity,'sku'=>$sku,'shipping_first_name'=>$shipping_first_name,'shipping_last_name'=>$shipping_last_name,'shipping_address_name'=>$shipping_address_name,'shipping_city'=>$shipping_city,'shipping_country'=>$shipping_country,'shipping_province_state'=>$shipping_province_state,'shipping_province_code'=>$shipping_province_code,'shipping_zip'=>$shipping_zip,'shipping_country_code'=>$shipping_country_code,'doubleside_tag'=>$double_tag,'created_at'=>$created_at);

                        $test = order::insert($values);
                        
                        
                        $meta_values = array('order_name'=>$name,'order_id' => $order_id,'sku' => $sku,'contact_email'=>$contact_email,'total_price'=>$current_total_price,'line_text_1'=> $line_text_1,'line_text_2'=> $line_text_2,'line_text_3'=> $line_text_3,'line_text_4'=> $line_text_4,'line_text_5'=> $line_text_5,'line_text_6'=> $line_text_6,'back_line_text_1'=> $back_line_text_1,'back_line_text_2'=> $back_line_text_2,'back_line_text_3'=> $back_line_text_3,'back_line_text_4'=> $back_line_text_4,'back_line_text_5'=> $back_line_text_5,'back_line_text_6'=> $back_line_text_6);

                        $test = OrderMeta::insert($meta_values);
                    }
                }       
            }
        }
    }
    
    
    public function get_orders(Request $request)
    {
        
        $orders = OrderMeta::get(['*']);
        
        return datatables()->of($orders)
        ->addColumn('action', function($row){
       
            $btn = '<a href="javascript:void(0)" id="editOrder" class="btn btn-primary btn-sm" data-id="'.$row->id.'">Edit</a>';
            //$btn = $btn.'<a href="javascript:void(0)" id="sendOrder" class="btn btn-success btn-sm" data-id="'.$row->id.'">Send</a>';

            return $btn;
        })        
        ->rawColumns(['action'])
        ->addIndexColumn()
        ->make(true);        
    }
    
    
    
    public function get_order_detail($id)
    {
    	$order = OrderMeta::where('id',$id)->first();

	    return response()->json([
	      'data' => $order
	    ]);
    }
    
    
    public function update_order(Request $request, $id)
    {
        
        $line_1 = $request->input('line_1');
        $line_2 = $request->input('line_2');
        $line_3 = $request->input('line_3');
        $line_4 = $request->input('line_4');
        $line_5 = $request->input('line_5');
        $line_6 = $request->input('line_6');

        $back_line_1 = $request->input('back_line_1');
        $back_line_2 = $request->input('back_line_2');
        $back_line_3 = $request->input('back_line_3');
        $back_line_4 = $request->input('back_line_4');
        $back_line_5 = $request->input('back_line_5');
        $back_line_6 = $request->input('back_line_6');
               
        $order_meta_edit = OrderMeta::where('id', $id)->update([

            'line_text_1' => $line_1,
            'line_text_2' => $line_2,
            'line_text_3' => $line_3,
            'line_text_4' => $line_4,
            'line_text_5' => $line_5,
            'line_text_6' => $line_6,
            'back_line_text_1' => $back_line_1,
            'back_line_text_2' => $back_line_2,
            'back_line_text_3' => $back_line_3,
            'back_line_text_4' => $back_line_4,
            'back_line_text_5' => $back_line_5,
            'back_line_text_6' => $back_line_6,
        ]);

        $order_data = OrderMeta::where('id', $id)->get(['order_id','sku']);

        $order_id = $order_data[0]->order_id;
        $sku = $order_data[0]->sku;

        
        $order_edit = Order::where('order_id', $order_id)->where('sku', $sku)->update([

            'line_text_1' => $line_1,
            'line_text_2' => $line_2,
            'line_text_3' => $line_3,
            'line_text_4' => $line_4,
            'line_text_5' => $line_5,
            'line_text_6' => $line_6,
            'back_line_text_1' => $back_line_1,
            'back_line_text_2' => $back_line_2,
            'back_line_text_3' => $back_line_3,
            'back_line_text_4' => $back_line_4,
            'back_line_text_5' => $back_line_5,
            'back_line_text_6' => $back_line_6,
        ]);

        return response()->json([ 'success' => true ]);
    }
    
    
    
}
