<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ReddingoOrder extends Model
{
    //
}
