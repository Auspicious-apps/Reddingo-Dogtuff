<?php

use Illuminate\Support\Facades\Route;
use App\Setting;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {

    $carrier = Setting::where('name','shipping_carrier')->get(['value']);
    $url = Setting::where('name','tracking_url')->get(['value']);

    $shipping_carrier = $carrier[0]->value;
    $tracking_url = $url[0]->value;

    return view('welcome',['shipping_carrier'=>$shipping_carrier,'tracking_url'=>$tracking_url ]);
})->middleware(['verify.shopify'])->name('home');

Route::post('order_create', 'OrderController@order_create');
Route::get('order-list', 'OrderController@get_orders')->name('order-list');
Route::get('order-edit/{id}', 'OrderController@get_order_detail');
Route::get('order-update/{id}', 'OrderController@update_order');
Route::post('create-tag/{id}', 'OrderController@create_tag');

Route::get('reddingo-order-list', 'ReddingoController@get_reddingo_orders')->name('reddingo-order-list');
Route::post('reddingo-order-status', 'ReddingoController@get_order_status');
Route::get('reddingo-order-update', 'ReddingoController@fetch_order_status');

Route::get('amazon-orders', 'AmazonController@order_create');


Route::post('save-settings', 'SettingController@save_settings');

